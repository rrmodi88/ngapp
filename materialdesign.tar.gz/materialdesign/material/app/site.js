var demoApp = angular.module('demoApp', [
  'ui.router',
  'ngMaterial',
  'homePageApp',
]);
